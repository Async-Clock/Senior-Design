import os.path
import sys
pathname = os.path.dirname(sys.argv[0])

pathname
